import React from 'react';

export function Todo() {
  return (
    <div>{props.title}</div>
  )
};

export default Todo;