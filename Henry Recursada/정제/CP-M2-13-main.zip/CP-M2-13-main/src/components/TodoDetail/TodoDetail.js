import React from 'react';

function TodoDetail() {
  return (
    <div>
      if(todo.id !== 'params'){<h1>No hay todo.</h1>}
    </div>
  )
};

export default TodoDetail;