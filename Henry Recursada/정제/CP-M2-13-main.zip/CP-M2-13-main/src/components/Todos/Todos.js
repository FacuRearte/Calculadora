import React from 'react';
import Todo from '../Todo/Todo';

export function Todos() {
  return (
    <div>
      
    </div>
  )
};

export default Todos;