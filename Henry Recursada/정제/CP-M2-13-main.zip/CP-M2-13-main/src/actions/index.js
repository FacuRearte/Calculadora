// Podes usar esta variable para generar un ID por cada Todo.
let todoId = 1
let payload = {
    title: '',
    status: '',
    id: 0
}

export function addTodo(payload) {
    return { type: 'AddTodo', payload: {title: payload.title, status: 'Todo', id: todoId++}}
}

export function removeTodo(payload) {
    return { type: 'RemoveTodo', payload}
}

export function toInProgress(payload) {
    return { type: 'ToInProgress', payload}
}

export function toDone(payload) {
    return { type: 'ToDone', payload}
}

// export const addTodo = undefined;

// export const removeTodo = undefined

// export const toInProgress = undefined;

// export const toDone = undefined;