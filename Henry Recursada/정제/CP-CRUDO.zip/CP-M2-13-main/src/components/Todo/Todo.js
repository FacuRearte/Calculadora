import React from 'react';

export function Todo() {
  return (
    <div>
      Componente Todo
    </div>
  )
};

export default Todo;