import React from 'react';

function TodoDetail() {
  return (
    <div>
      Componente TodoDetail
    </div>
  )
};

export default TodoDetail;