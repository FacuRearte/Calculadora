'use strict';

var tasks = {}; // acá vamos a guardar nuestras personas y tareas
// PISTA: Taks es un objeto donde cada propiedad (nombre de una persona)
// tiene asociada como valor un array de to-dos


module.exports = {
  reset: function () {
    tasks = {}; // esta función ya esta armada :D
  },
  // ==== COMPLETEN LAS SIGUIENTES FUNCIONES (vean los test de `model.js`) =====
  listPeople: function () {
    // devuelve un arreglo de personas con tareas
  },
  add: function (name, task) {
    // guarda una tarea para una persona en particular
  }
  // etc.
};
