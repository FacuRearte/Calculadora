'use strict';

var express = require('express');
var router = express.Router();
module.exports = router;

// escriban sus rutas acá
// siéntanse libres de dividir entre archivos si lo necesitan
