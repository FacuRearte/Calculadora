Plantilla creada con ♥ Por los PM del Grupo 9 para los Alumnos del Stand así pueden practicar.

Dependencias instaladas en el Repo:
- React
- Redux
- React Router Dom

Intrucciones para empezar a trabajar en el Archivo:
- npm install

Y listo! Buena suerte y que se diviertan.

![image](https://user-images.githubusercontent.com/66447745/116758249-06684100-a9e6-11eb-8131-184f8548bbec.png)
