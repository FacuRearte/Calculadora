import React from 'react'

const Test = () => {
    return (
        <div>
          <h1>Componente de Prueba</h1>
        </div>
    )
}

export default Test