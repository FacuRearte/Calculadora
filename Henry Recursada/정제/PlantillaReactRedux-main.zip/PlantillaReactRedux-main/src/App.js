import Test from './components/Test'
import './App.css';

function App() {
  return (
    <div className="App">
      <Test/>
    </div>
  );
}

export default App;
